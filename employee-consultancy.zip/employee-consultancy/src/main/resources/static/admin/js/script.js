  let toast = document.querySelector(".toast-msg");
  setTimeout(()=>{
             toast.remove();
         },3000)
