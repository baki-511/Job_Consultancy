package com.consultancy;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmployeeConsultancyApplicationTests {

	@Test
	void contextLoads() {
	}

}
